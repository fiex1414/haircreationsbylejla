new Vue({
    el: '#app',
    vuetify: new Vuetify(),

    data() {
        return {
            drawer: null
        };
    },
})